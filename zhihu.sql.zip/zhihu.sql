-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2017 年 08 月 03 日 08:48
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `zhihu`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `comment`
-- 

CREATE TABLE `comment` (
  `id` smallint(6) unsigned NOT NULL auto_increment,
  `titleid` smallint(6) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  `date` datetime NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- 导出表中的数据 `comment`
-- 

INSERT INTO `comment` VALUES (1, 0, '', '哈哈', '2017-08-03 15:54:32');
INSERT INTO `comment` VALUES (2, 0, 'undefined', '我们', '2017-08-03 16:00:38');

-- --------------------------------------------------------

-- 
-- 表的结构 `question`
-- 

CREATE TABLE `question` (
  `id` smallint(6) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL,
  `point` varchar(100) NOT NULL,
  `myEditor` text,
  `name` varchar(20) NOT NULL,
  `date` datetime NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- 导出表中的数据 `question`
-- 

INSERT INTO `question` VALUES (3, '做一名化妆师是怎么样的体验？', '时尚', '<p>从学校出来接过的第一个新娘妆。<br/>新娘结婚当天，化好妆一切准备妥当。结果在酒店里新郎新娘吵起来了。新娘一边跑一边哭，后边一大群在追。然后，新娘妈妈登场了，她说，有啥大不了的，不开心咱们不嫁了。当时觉得好感动。<br/>这么多年过去了，一直记得她妈妈说的话。不是指责不是说这么多亲戚朋友在外面等着啊吧啦吧啦。</p>', '', '2017-08-02 21:08:03');
INSERT INTO `question` VALUES (4, '如何评价大漠穷秋的文章《Angular有哪些地方比Vue更优秀？》?', '时尚', '我曾经问过我的老板和Angular团队的负责人这样一个问题：在中国国内的网络上经常出现针对Angular的讨论，有一些内容非常偏激，甚至可以说【恶毒】，作为Angular在国内推广的负责人，我可以去和这些人针锋相对吗？<br/>我的老板是这样跟我说的：“战胜”竞争对手不是Angular团队的目标，我们的目标是帮助开发者和企业更好地开发面向未来的WEB应用。<br/>很平常的一句话，但是给我留下的印象非常深刻，因为我看到了一个全新的角度，原来他们是这样去思考问题的。<br/>反观国内的很多技术讨论区，很多情况下会非常快速地陷入人身攻击和胡扯的境地，给人的感觉就像泼妇骂街一样。尤其是前端社区，越来越像娱乐圈。<br/>所有的参与者，包括提问题的人，请你们安静一秒钟，仔细想想，你自己想要什么？在口水战中战胜对手能帮助你提高编码技巧，还是能帮助你提高认识世界的高度', '', '2017-08-02 21:10:23');
INSERT INTO `question` VALUES (5, '你有哪些一鸣惊人的操作？', '生活方式', '<p>我表姐快五十了没有结婚，名牌大学毕业，二线城市，工作稳定，年薪大概在五六十万，房两套，股票两百多万，双商高，性格独立坚强，自己生活完全没有问题，但是还是遗憾自己未婚，所以以前也一直努力给我介绍对象，为什么，她说人生就是应该酸甜苦辣都尝尝。<br/>说实话，回答这个问题的人，能达到我姐这个层次的，不管是经济，年龄，智商还是能力，估计也没几个，所以大家还是不要把独身生活想得那么美好，把婚姻想得那么不堪，把话说得那么绝对，不要被带节奏，一个人生活也是柴米油盐酱醋茶，不会被比两个人轻松多少，有机会还是结个婚，毕竟还有一半的几率是幸福啊，而且不行离婚好了，最多回到单身不是，也没更差。所以大家一起努力脱单吧。</p>', '', '2017-08-02 21:33:07');
INSERT INTO `question` VALUES (6, '在哪一刻你觉得你和朋友再也做不成朋友了？', '生活方式', '<p>高中曾经的挚友。</p><p>俩人身高都过180，低音炮，一黑一白，性格互补，一直以为一生挚友无疑了。</p><p>高中晚自习一次我心情不好，自行消失，没想到他看我不在教室，居然找到了躲在还在装修的操场边上的小教室里面的我。</p><p>一句话没说，两个人坐在操场上，他在抽烟，我在听歌。</p><p>有一天，跟他从小玩儿到大的好朋友和他绝交，那个人也是我的好朋友。</p><p>劝我说：他就是个白眼狼，越早绝交越好，艹。</p><p>我没理。</p><p>有一天，体育老师开车送我回家，劝我不要跟他玩儿：</p><p>“他背后骂人骂得比较多，也说过你。”</p><p>我没信。</p><p>有一天，班主任打电话给我母亲，说：</p><p>“叫你家A不要跟他玩儿，会变坏的。”</p><p>我无奈。</p><p><br/></p><p>是的，他抽烟喝酒打架，我在学校装好学生，两个反差。</p><p>他罪名比较多，再额外多一个就被开除很简单，偶尔我会帮他背黑锅。</p><p>有一天，他在宿舍吹牛逼，也许没看到我进去，就跟宿舍的人说：</p><p><strong>“A自己犯贱，帮我背黑锅，我又没求他，他自愿的。”</strong></p>', '', '2017-08-02 21:34:54');

-- --------------------------------------------------------

-- 
-- 表的结构 `user`
-- 

CREATE TABLE `user` (
  `id` smallint(4) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `tel` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- 导出表中的数据 `user`
-- 

INSERT INTO `user` VALUES (1, 'zhangqian', '18892614915', '4de37cf64c50d3f2a6ddca06d37ae4c7cda53e40');
INSERT INTO `user` VALUES (2, 'haha', '13349517771', '4de37cf64c50d3f2a6ddca06d37ae4c7cda53e40');
